package minilib.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import minilib.util.*;
import minilib.vo.*;
import java.util.ArrayList;
import java.util.List;


import minilib.util.DButil;
import minilib.vo.Title;

//管理书目
public class ManageTitlesDao {
	
	public List findAll(int page) {
		List list = new ArrayList();
		try {
			Connection con = DButil.getConnection();
			if(con == null) {
				System.out.println("connect fail!");
			}
			String sql = "select * from t_book order by bookid limit ?,?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, (page-1)*10);
			pstmt.setInt(2, 10);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				Title title = new Title();
				title.setISBN(rs.getString(3));
				title.setBookname(rs.getString(5));
				title.setWriter(rs.getString(6));
				title.setPress(rs.getString(8));
				list.add(title);
			}
			rs.close();
			pstmt.close();
			con.close();
		}catch(SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
