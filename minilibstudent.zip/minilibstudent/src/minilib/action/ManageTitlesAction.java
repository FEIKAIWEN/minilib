package minilib.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import minilib.dao.ManageTitlesDao;

public class ManageTitlesAction extends ActionSupport {
	
	public String addTitle() {
		return "addbook";
	}
	
	public String findAllTitles() {
		ManageTitlesDao mt = new ManageTitlesDao();
		String page="1";
		HttpServletRequest request = ServletActionContext.getRequest();
		List allTitleslist=mt.findAll(Integer.parseInt(page));
		request.setAttribute("alltitleslist", allTitleslist);
		System.out.println("====findall====");
		return "querybook";
	}
	
	public String findByPage() {
		ManageTitlesDao mt = new ManageTitlesDao();
		String page;
		HttpServletRequest request = ServletActionContext.getRequest();
		page = request.getParameter("page");
		List allTitleslist=mt.findAll(Integer.parseInt(page));
		request.setAttribute("alltitleslist", allTitleslist);
		System.out.println("====findall====");
		return "querybook";
	}
}
