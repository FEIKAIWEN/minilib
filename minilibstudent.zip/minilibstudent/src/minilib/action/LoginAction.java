package minilib.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import minilib.vo.User;

public class LoginAction extends ActionSupport
{
	User user = new User();
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String execute() throws Exception {
		if(user.getName().equals("zhang") && user.getPass().equals("000000"))
		{
			//将用户写入session,这个应该是servlet包中内含的类和相关函数功能
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			session.setAttribute("username", user.getName());
			
			//为了使返回的字符串有意义，在Struts中进行配置
			return "success";
		}
		else
			return "error";
	}
	
	
}
