package minilib.util;

import java.sql.Connection;		//是sql中的C哦你nection，不是mysql中的！！！！
import java.sql.DriverManager;



public class DButil {
	
	//数据库的用户信息
	private static String DBname = "root";
	private static String DBpass = "root";
	
	//数据库驱动
	private static String driver = "com.mysql.jdbc.Driver";
	
	//数据库位置
	private static String url = "jdbc:mysql://localhost:3306/book";
	
	//创建与数据库连接
	public static Connection getConnection()throws Exception{
		Class.forName(driver).newInstance();
		return DriverManager.getConnection(url, DBname, DBpass);
	}
}
